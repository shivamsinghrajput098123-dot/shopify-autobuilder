AUTOBUILDER · LOCAL DASHBOARD
=============================

Option A (sabse easy, kuch install nahi)
  1. public/index.html par double-click karo. Browser me khul jayega.

Option B (localhost:3000 par, jaisa aapne maanga)
  1. Node.js install karo (nodejs.org se "LTS" download).
  2. Is folder me terminal / command prompt kholo.
  3. Ye command chalao:   node server.js
  4. Browser me kholo:    http://localhost:3000
  Band karne ke liye terminal me Ctrl + C dabao.

Option C (agar Python hai)
  1. Terminal me folder "public" ke andar jao.
  2. Chalao:  python -m http.server 3000
  3. Kholo:   http://localhost:3000

Kya kaam karta hai abhi
  - CSV upload: products aur collections nikalta hai (Shopify export format)
  - AI builder: demo rules se sections on/off, style, headline badalta hai
  - Festival calendar: date ke hisaab se banner auto-switch
  - Preview: desktop/mobile, "Test date" se festival check
  - Download: poora homepage HTML file ban jata hai

Abhi kaam nahi karta (next steps)
  - Asli AI model (app.js me "TODO" dekho)
  - Shopify se connection / live publish
  - Theme zip ko asli me use karna
